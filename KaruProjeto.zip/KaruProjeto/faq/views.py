from django.shortcuts import render, get_object_or_404
from .models import Pergunta


def faq_list(request):
    """
    Lista todas as perguntas cadastradas.
    """
    perguntas = Pergunta.objects.all()
    return render(request, 'faq/list.html', {'perguntas': perguntas})


def faq_detail(request, pk):
    """
    Mostra os detalhes de uma única pergunta.
    """
    pergunta = get_object_or_404(Pergunta, pk=pk)
    return render(request, 'faq/detail.html', {'pergunta': pergunta})
