﻿from django.db import models

class Pergunta(models.Model):
    texto = models.TextField('Pergunta')
    ordem = models.PositiveIntegerField('Ordem de exibição', default=0)
    criada_em = models.DateTimeField('Criada em', auto_now_add=True)

    class Meta:
        ordering = ['ordem', 'texto']
        verbose_name = 'pergunta'
        verbose_name_plural = 'perguntas'

    def __str__(self):
        return self.texto[:80]


class Resposta(models.Model):
    pergunta = models.OneToOneField(Pergunta, on_delete=models.CASCADE, related_name='resposta')
    texto = models.TextField('Resposta')
    atualizada_em = models.DateTimeField('Atualizada em', auto_now=True)

    class Meta:
        verbose_name = 'resposta'
        verbose_name_plural = 'respostas'

    def __str__(self):
        return f"Resposta para: {self.pergunta.texto[:50]}"
