from django.contrib import admin
from .models import Pergunta, Resposta

@admin.register(Pergunta)
class PerguntaAdmin(admin.ModelAdmin):
    list_display = ('texto', 'ordem', 'criada_em')
    search_fields = ('texto',)
    ordering = ('ordem', 'criada_em')

@admin.register(Resposta)
class RespostaAdmin(admin.ModelAdmin):
    list_display = ('pergunta', 'atualizada_em')
    search_fields = ('pergunta__texto', 'texto')
    raw_id_fields = ('pergunta',)